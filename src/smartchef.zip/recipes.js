module.exports = {
    "steak": {
          "recipe": "Classic pan seared steak",
          "category": "meat",
          "primary-ingredient": "steak",
          "ingredients": "olive oil and one tablespoon",
          "equipment": [
            "oven-safe pan",
            "oven"
          ],
          "servings": 1,
          "instructions": "Preheat the oven to 400 degrees Fahrenheit."
        },
    "backing" : {}
}