module.exports = {
    "pan seared steak": "The ingredients for steak are: one steak, a pinch of freshly ground black pepper, a half inch of butter, one sprig of thyme, two cloves of garlic, and one tablespoon of olive oil.",
};